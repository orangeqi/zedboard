#ifndef HOST_H
#define HOST_H

#include "typedefs.h"

// Limit angles to 90 degree.
const int NUM_DEGREE = 90;

#endif
